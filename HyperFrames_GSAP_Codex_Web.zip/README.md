# HyperFrames + GSAP for Codex Web

This ZIP contains three **compact, independently authored** Skills, not the complete upstream HyperFrames skill collection.

## Installation
1. Extract this ZIP.
2. Upload the `.agents/skills/` directory into the root of your GitHub repository, keeping its structure.
3. Commit the files to the branch that Codex Web will use.
4. Open chatgpt.com/codex and select that repository and branch.
5. Ask Codex to read `.agents/skills/hyperframes/SKILL.md`, `.agents/skills/gsap/SKILL.md`, and `.agents/skills/hyperframes-cli/SKILL.md`.

## Full upstream source
https://github.com/heygen-com/hyperframes

## Example request
Use the three project Skills to create a Vietnamese 1920x1080 biology animation explaining chromosome condensation. Define a DESIGN.md, create HTML/GSAP scenes, lint, inspect and render MP4 if the environment supports it.
